package com.example.blind_assist

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
